

const ModulesPanel = () => {
  return (
    <div>ModulesPanel</div>
  )
}

export default ModulesPanel
//Código del formulario para editar el perfil del usuario
const EditProfileForm = () => {
  return (
    <div>EditProfileForm</div>
  )
}

export default EditProfileForm
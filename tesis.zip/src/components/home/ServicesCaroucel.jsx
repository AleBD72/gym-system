

const ServicesCaroucel = () => {
  return (
    <div>ServicesCaroucel
        <p className="font-poppins text-white">Pendiente</p>
    </div>
  )
}

export default ServicesCaroucel


const EditEventForm = () => {
  return (
    <div>EditEventForm</div>
  )
}

export default EditEventForm
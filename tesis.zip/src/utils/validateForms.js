import * as Yup from 'yup';

//Validar campos de login
export const LoginValidate = Yup.object().shape({
    email: Yup.string().email('Correo no válido').required('Campo requerido'),
});

//Validar campos de register
export const RegisterValidate = Yup.object().shape({
    name: Yup.string().min(4, 'Mínimo 4 caracteres').max(10, 'Máximo 10 caracteres').required('Campo requerido'),
    last_name: Yup.string().min(4, 'Mínimo 4 caracteres').max(10, 'Máximo 10 caracteres').required('Campo requerido'),
    birth: Yup.date().max(new Date(), 'Este valor no puede ser en el futuro').test('fechaAnterior', 'La fecha ingresada no es válida', function (value) {
        const seisAniosAtras = new Date();
        seisAniosAtras.setFullYear(seisAniosAtras.getFullYear() - 16);
        return value <= seisAniosAtras
    }).required('Campo requerido'),
    cedula: Yup.number().required('Campo requerido').test('longitud', 'El número debe tener 10 cifras', function (value) {
        // Validar que el número tenga exactamente 10 cifras
        return value && value.toString().length === 10;
    }),
    //password: Yup.string().min(6, 'La contraseña debe tener mínimo 6 carcateres').required('Campo obligatorio'),
    //confirmation: Yup.string().oneOf([Yup.ref('password'), null], 'Las contraseñas deben coincidir').required('Campo obligatorio'),
    email: Yup.string().email('Correo no válido').required('Campo requerido'),
});

//Valdiar campos de ingreso de eventos a horarios
export const ScheduleValidate = Yup.object().shape({
    name: Yup.string().min(5, 'Mínimo 5 caracteres').max(40, 'Máximo 40 caracteres').required('Campo requerido'),
    //day: Yup.string().required('Campo requerido'),
    trainer: Yup.string().min(5,'Mínimo 5 caracteres').required('Campo obligatorio')
});

//Validar caompos al editar el perfil
export const ProfileValidate = Yup.object().shape({
    city: Yup.string().min(4, 'Se requiere mínimo 4 carcteres').max(15, 'Máximo 15 caracteres'),
    country: Yup.string().min(4, 'Se requiere mínimo 4 carcteres').max(15, 'Máximo 15 caracteres'),
    nickname: Yup.string().min(3, 'Mínimo 3 caracteres'),
    description: Yup.string().max(60, 'Solo se puede ingresar 60 caracteres'),
    birth: Yup.date().max(new Date(), 'Este valor no puede ser en el futuro').test('fechaAnterior', 'La fecha ingresada no es válida', function (value) {
        const seisAniosAtras = new Date();
        seisAniosAtras.setFullYear(seisAniosAtras.getFullYear() - 16);
        return value <= seisAniosAtras
    }).required('Campo requerido'),

})
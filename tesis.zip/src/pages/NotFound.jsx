

const NotFound = () => {
  return (
    <div>NotFound page</div>
  )
}

export default NotFound
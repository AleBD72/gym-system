

const ScheduleAdmin = () => {
  return (
    <div>ScheduleAdmin</div>
  )
}

export default ScheduleAdmin